# SocialLidia
SEW Projekt 2019 Kathrin Schrenk &amp; Lidia Rudenko
