﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialLidia
{
    class Nachricht : Beitragx
    {
        public Nachricht(Datei newSpeicherDatei, string newErsteller, string newInhalt) : base(newSpeicherDatei, newErsteller, newInhalt)
        {

        }

        
    }
}
